/*
* To be used at a later date.
*/
//import React from 'react';
import React, { Component } from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';

export default class CreateNew extends Component {
    render() {
      return (
        <div>
          <p>You are on the CreateNew component!</p>
        </div>
      )
    }
  }