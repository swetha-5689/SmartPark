//Charles Owen
//Database key for Mongo
module.exports = {
    mongoURI : 'mongodb+srv://chuck:chuck123@cluster0-zzery.mongodb.net/test?retryWrites=true&w=majority'
}